# RCODE FOR
# EVOLUTION OF MYCORRHIZAL RESPONSE
# C. DELAVAUX & J. BEVER
# UPDATED 2.8.21

# NOTE: THIS R CODE CONTAINS PARTIAL ANALYSIS FOR THIS MS
# SEE .SAS SCRIPTS FOR REMAINING ANALYSES

#load packages
library(lme4)
library(lmerTest)
library(lsmeans)
library(ggplot2)
library(gridExtra)
library(tidyverse)
library(car)

################################
################################
### Mycorrhizal Colonization ###
################################
################################

#read data:
col<-read.table("MIRKS2019_slidesR.txt", header= TRUE)

#correct treatments; as factor:
col$Treatment<-as.factor(col$Treatment)
col$T2<-as.factor(col$T2)

#rename:
col$Population<-"Native"
col$Population[col$Pop=="OF"]<-"Post-agricultural"
col$Pop<-col$Population
col$Population<-NULL
col$Species2<-"Dogbane"
col$Species2[col$Species=="IW"]<-"Ironweed"
col$Species2[col$Species=="MW"]<-"Milkweed"
col$Species2[col$Species=="SL"]<-"Solidago"
col$Species<-col$Species2
col$Species2<-NULL
col$Treatment2<-"Sterile"
col$Treatment2[col$Treatment=="1"]<-"Native"
col$Treatment2[col$Treatment=="2"]<-"Non-native"
col$Treatment<-col$Treatment2
#relevel:
col$Species <- factor(col$Species,
                         levels = c('Dogbane','Solidago', "Ironweed", "Milkweed"),ordered = FALSE)
col$Treatment <- factor(col$Treatment,
                      levels = c('Sterile','Native', "Non-native"),ordered = FALSE)

####################
####################
#### M1- COL MS ####
####################
####################

#AMF V STERILE:
col$Treatment3<-"AMF"
col$Treatment3[col$Treatment=="Sterile"]<-"Sterile"

col.glm3<- glmer(cbind(YES,NO)~Treatment3 + (1|Species:Pop),
                     data = col, family = binomial(link="logit"))

summary(col.glm3)
anova(col.glm3)

#ALL TREATMENTS:
col.glm<- glmer(cbind(YES,NO)~Treatment + (1|Species:Pop),
                data = col, family = binomial(link="logit"))

summary(col.glm)
anova(col.glm)

#Fig S1 PLOT:
ref.col<-lsmeans(col.glm,pairwise~Treatment,data= col)
ref.table.col<-as.data.frame(ref.col$lsmeans)

#back convert to percent colonization:
ref.table.col$lsmean.c <- (exp(ref.table.col$lsmean))/(1+exp(ref.table.col$lsmean))
ref.table.col$SE.down.c <- (exp(ref.table.col$lsmean))/(1+exp(ref.table.col$lsmean))  - (exp(ref.table.col$lsmean-ref.table.col$SE))/(1+exp(ref.table.col$lsmean-ref.table.col$SE))
ref.table.col$SE.up.c <- (exp(ref.table.col$lsmean+ref.table.col$SE))/(1+exp(ref.table.col$lsmean+ref.table.col$SE))-(exp(ref.table.col$lsmean))/(1+exp(ref.table.col$lsmean))

S1<-
  ggplot(ref.table.col, aes(Treatment, 100*lsmean.c)) + 
  geom_point(position=position_dodge(1), size =4) + 
  scale_color_brewer(palette = "Accent")+
  geom_errorbar(aes(ymin=100*lsmean.c-100*SE.down.c, ymax=100*lsmean.c+100*SE.up.c), width=.5,size=1, position=position_dodge(1)) + 
  theme_bw()+
  scale_y_continuous(name = "Mycorrhizal colonization (percent)")+
  xlab("AMF Inocula")+
  #labs(colour = "Population Type")+
  theme(text = element_text(size = 18, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        axis.text.x=element_text(size = 15),
        axis.text.y=element_text(size = 15),
        legend.position = "bottom")
S1

####################
####################
##### M2- COL ######
##### 2 TREAT ######
####################
####################

col<-col[!col$Treatment=="Sterile",]
col.glm.int<- glmer(cbind(YES,NO)~Treatment+Species+Pop*Treatment+(1|Species:Pop)+(1|Species:Pop:Treatment),
                    data = col, family = binomial(link="logit"))

summary(col.glm.int)
anova(col.glm.int)

ref.col.int<-lsmeans(col.glm.int,pairwise~Pop*Treatment,data=col)
ref.table.col.int<-as.data.frame(ref.col.int$lsmeans)
ref.table.col.int
ref.table.col.int<-ref.table.col.int[!ref.table.col.int$Treatment=="Sterile",]
mean<-ref.table.col.int %>%
  group_by(Pop)%>%
  summarize(lsmean=mean(lsmean))%>%
  as.data.frame()

mean.SE<-ref.table.col.int %>%
  group_by(Pop)%>%
  summarize(SE=mean(SE))%>%
  as.data.frame()

ref.table.col.int<-merge(mean,mean.SE,by ="Pop")

#back convert to percent colonization:
ref.table.col.int$lsmean.c <- (exp(ref.table.col.int$lsmean))/(1+exp(ref.table.col.int$lsmean))
ref.table.col.int$SE.down.c <- (exp(ref.table.col.int$lsmean))/(1+exp(ref.table.col.int$lsmean))  - (exp(ref.table.col.int$lsmean-ref.table.col.int$SE))/(1+exp(ref.table.col.int$lsmean-ref.table.col.int$SE))
ref.table.col.int$SE.up.c <- (exp(ref.table.col.int$lsmean+ref.table.col.int$SE))/(1+exp(ref.table.col.int$lsmean+ref.table.col.int$SE))-(exp(ref.table.col.int$lsmean))/(1+exp(ref.table.col.int$lsmean))

#FIG 1 PLOT:
F1<-
  ggplot(ref.table.col.int, aes(Pop, 100*lsmean.c)) + 
  geom_point(position=position_dodge(1), size =4) + 
  scale_color_brewer(palette = "Accent")+
  geom_errorbar(aes(ymin=100*lsmean.c+100*SE.up.c, ymax=100*lsmean.c-100*SE.down.c), width=.5,size=1, position=position_dodge(1)) + 
  theme_bw()+
  scale_y_continuous(name = "Mycorrhizal colonization (percent)")+
  xlab("Population Type")+
  labs(colour = "Population Type")+
  theme(text = element_text(size = 20, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        axis.text.x=element_text(size = 15),
        axis.text.y=element_text(size = 15),
        legend.position = "bottom")
F1

################################
################################
########## ROOT LENGTH #########
################################
################################

#read data:
winlen<- read.table("Winrhizo19_R.txt", header=TRUE)
#merge with biomass data
bio<-read.csv('MIRKSexp1SAS ranks_12_12_2019.csv')
winlen<-merge(winlen, bio, by="plant_name", all.x=TRUE)
#make new RL.mass variable = root length/biomass:
winlen$RL.mass<- winlen$tot_length/winlen$biomass_b
winlen$RL.mass<-log(winlen$RL.mass)
#relevel
winlen$species <- factor(winlen$species,
levels = c('Dogbane','Solidago', "Ironweed", "Milkweed"),ordered = FALSE)

winlen$Population<-"Native"
winlen$Population[winlen$poptype=="OF"]<-"Post-agricultural"
winlen$poptype<-winlen$Population
winlen$Population<-NULL

####################
####################
###### M1- RL ######
##### SPECIES ######
####################

lmwin<-lmer(log(RL.mass)~species+(1|poptype:species), data=winlen)
summary(lmwin)
anova(lmwin)

#FIG S2 PLOT:
ref.rl<-lsmeans(lmwin,pairwise~species, data = winlen)
ref.table.rl<-as.data.frame(ref.rl$lsmeans)

S2<-ggplot(ref.table.rl, aes(species, lsmean)) + 
  geom_point(position=position_dodge(1), size =4) + 
  scale_color_brewer(palette = "Accent")+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5,size=1, position=position_dodge(1)) + 
  theme_bw()+
  scale_y_continuous(name = "Root length (log)")+
  xlab("Species")+
  labs(colour = "Population type")+
  theme(text = element_text(size = 18, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        axis.text.x=element_text(size = 15),
        axis.text.y=element_text(size = 15),
        legend.position = "bottom")+
  scale_fill_brewer(palette = "Dark2")
S2

####################
####################
###### M2- RL ######
##### SP * POP #####
####################

lmwinpopsp<-lmer(log(RL.mass)~species*poptype+(1|poptype:species), data=winlen)
summary(lmwinpopsp)
anova(lmwinpopsp)

################################
################################
############# MGR ##############
################################
################################

#ESTIMATES COME FROM SAS OUTPUT
##FIG 2 PLOT:

df <- data.frame(Population=rep(c("Post-agricultural","Native"), each=2),
                  Inocula=rep(c("Native","Non-native"),2),
                  MGR=c(1.465759479,
                        1.847830891,
                        1.68795395,
                        1.586053108))
df$se<- c(0.146307281,
          0.144603396,
          0.16094826,
          0.163685117)

p2a <- ggplot(data=df, aes(x=Inocula, y=MGR, fill=Population)) +
  geom_bar(alpha=0.7,color ="black", stat="identity", position=position_dodge(width=1.000000000000000000000000000001))+
  scale_y_continuous(name = "Mycorrhizal response")+
  geom_errorbar(aes(ymin=MGR-se, ymax=MGR+se), width=.2,
                position=position_dodge(1))+
  theme_bw() +
  theme(plot.title = element_text(size = 14, family = "Tahoma", face = "bold"),
        text = element_text(size = 12, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        axis.text.x=element_text(size = 11),
        legend.position = "bottom") +
  scale_fill_brewer(palette = "Accent")

p2a <-p2a + labs(fill = "Population Type")


df2 <- data.frame(Population=rep(c("Post-agricultural","Native"), each=1),
                  Species=rep(c("Dogbane","Ironweed", "Milkweed","Solidago"), each=2),
                  MGR=c(-0.02754693,	
                        1.291831558,
                        2.007963036,
                        0.590250123,
                        5.749409962,
                        6.216778259,
                        1.151332943,
                        1.063419502))
df2$se<- c(0.232550887,
           0.772436847,
           0.198213975,
           0.126470983,
           1.632416877,
           1.384718393,
           0.134017748,
           0.151396318)
#relevel:
df2$Species <- factor(df2 $Species,
                      levels = c('Dogbane','Solidago', "Ironweed", "Milkweed"),ordered = FALSE)


p2b <- ggplot(data=df2, aes(x=Population, y=MGR, fill=Population)) +
  geom_bar(alpha=0.7,color="black",stat="identity", position=position_dodge(width=2))+
  scale_y_continuous(name = "Mycorrhizal response")+
  geom_errorbar(aes(ymin=MGR-se, ymax=MGR+se), width=.2,
                position=position_dodge(.9))+
  theme_bw() +
  theme(plot.title = element_text(size = 14, family = "Tahoma", face = "bold"),
        text = element_text(size = 12, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        axis.title.x = element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        legend.position = "bottom")+
  scale_fill_brewer(palette = "Accent")+
  facet_grid(~Species)
p2b<-p2b + labs(fill = "Population Type")

grid.arrange(p2a,p2b,nrow=2)

################################
################################
####### CORRELATIONS ###########
################################
################################

#ROOT LENGTH ~ MGR: RL*species model
winlenMGR<- read.table("Winrhizo19_MGR_Popbysp.txt", header=TRUE)
str(winlenMGR)

#rename/level:
winlenMGR$Population<-"Native"
winlenMGR$Population[winlenMGR$poptype=="OF"]<-"Post-agricultural"
winlenMGR$Population<-NULL

#relevel:
winlenMGR$species <- factor(winlenMGR$species,
                      levels = c('Dogbane','Solidago', "Ironweed", "Milkweed"),ordered = FALSE)
#scale:
winlenMGR$RL.mass<-scale(winlenMGR$RL.mass)
winlenMGR$MGR2<-scale(winlenMGR$MGR2)

####################
####################
#### M1- MGR.RL ####
####################
####################

root.by.resp.int.sp<-lmer(MGR2~RL.mass*species+(1|poptype:species), data=winlenMGR)
summary(root.by.resp.int.sp)#all NS
anova(root.by.resp.int.sp)

####################
####################
#### COL ~ MGR #####
####################
####################

winlenMGR$propcol<-winlenMGR$Mcol.Y/(winlenMGR$Mcol.Y+winlenMGR$Mcol.N)
winlenMGR$lt.propcol<-logit(winlenMGR$propcol)
winlenMGR$MGR2

######################
######################
## M2- MGR.popcol ####
######################
######################

col.by.resp.logit.3<-lmer(MGR2~ lt.propcol+poptype+species+lt.propcol:poptype + lt.propcol:species+(1|species:poptype),data = winlenMGR)
summary(col.by.resp.logit.3)
anova(col.by.resp.logit.3)

#FIG S3 PLOT:
datplot4 <- ggeffect(col.by.resp.logit.3, terms = c("lt.propcol","species"), type= "re") 

IW.dat4<-datplot4[datplot4$group == "Ironweed",] #11
MW.dat4<-datplot4[datplot4$group == "Milkweed",] #11
SL.dat4<-datplot4[datplot4$group == "Solidago",] #11
DB.dat4<-datplot4[datplot4$group == "Dogbane",] #11

winlenDB<-winlenMGR[winlenMGR$species=="Dogbane",]
winlenMW<-winlenMGR[winlenMGR$species=="Milkweed",]
winlenSL<-winlenMGR[winlenMGR$species=="Solidago",]
winlenIW<-winlenMGR[winlenMGR$species=="Ironweed",]

par(font.axis=1)
par(font.lab=2)
plot(IW.dat4$x,IW.dat4$predicted,type="l",col="#68228B80",cex.lab=1, lwd =2, xlim=c(-2,2), ylim=c(-3.5,3.5),cex.axis=1.25,cex.lab=1.75,
     xlab="Mycorrhizal colonization",ylab="Mycorrhizal response")
points(MW.dat4$x,MW.dat4$predicted, type="l",col="#228B2280",cex.lab=1, lwd =2)
points(DB.dat4$x,DB.dat4$predicted, type="l",col="#0000FF80",cex.lab=1, lwd =2)
points(SL.dat4$x,SL.dat4$predicted, type="l",col="#FFA50080",cex.lab=1, lwd =2)

points(winlenIW$lt.propcol,winlenIW$MGR2, xlab="",ylab="",main= "", pch=19,  cex.lab= 2.5, col="#68228B80", cex.main = 3,cex=1.5)
points(winlenMW$lt.propcol,winlenMW$MGR2, main= "", pch=19,  cex.lab= 2.5, col="#228B2280", cex.main = 3,cex=1.5)
points(winlenDB$lt.propcol,winlenDB$MGR2, main= "", pch=19,  cex.lab= 2.5, col="#0000FF80", cex.main = 3,cex=1.5)
points(winlenSL$lt.propcol,winlenSL$MGR2, main= "", pch=19,  cex.lab= 2.5, col="#FFA50080", cex.main = 3,cex=1.5)

polygon(c(IW.dat4$x,rev(IW.dat4$x)),c(IW.dat4$conf.low,rev(IW.dat4$conf.high)),col="#68228B33", lty=0, lwd=0.05)
polygon(c(MW.dat4$x,rev(MW.dat4$x)),c(MW.dat4$conf.low,rev(MW.dat4$conf.high)),col="#228B2233", lty=0, lwd=0.05)
polygon(c(DB.dat4$x,rev(DB.dat4$x)),c(DB.dat4$conf.low,rev(DB.dat4$conf.high)),col="#0000FF33", lty=0, lwd=0.05)
polygon(c(SL.dat4$x,rev(SL.dat4$x)),c(SL.dat4$conf.low,rev(SL.dat4$conf.high)),col="#FFA50033", lty=0, lwd=0.05)

legend(x=1, y =3.5, legend= c("Ironweed","Milkweed","Dogbane","Solidago"), col = c("#68228B80","#228B2280","#0000FF80","#FFA50080"),box.lty=0, pch=19, cex =1.5)

#PLOT FIG 3:
datplot4 <- ggeffect(col.by.resp.logit.3, terms = c("lt.propcol","poptype"), type= "re") 

OF.dat4<-datplot4[datplot4$group == "OF",]
R.dat4<-datplot4[datplot4$group == "R",]

OF.winlen<-winlenMGR[winlenMGR$poptype=="OF",]
R.winlen<-winlenMGR[winlenMGR$poptype=="R",]

par(font.axis=1)
par(font.lab=2)
plot(OF.dat4$x,OF.dat4$predicted,type="l",col="#68228B80",cex.lab=1, lwd =2, xlim=c(-2,2), ylim=c(-2.5,2.5),cex.axis=1.25,cex.lab=1.75,
     xlab="Mycorrhizal colonization",ylab="Mycorrhizal response")
points(R.dat4$x,R.dat4$predicted, type="l",col="#228B2280",cex.lab=1, lwd =2)

points(OF.winlen$lt.propcol,OF.winlen$MGR2, xlab="",ylab="",main= "", pch=19,  cex.lab= 2.5, col="#68228B80", cex.main = 3,cex=1.5)
points(R.winlen$lt.propcol,R.winlen$MGR2, main= "", pch=19,  cex.lab= 2.5, col="#228B2280", cex.main = 3,cex=1.5)

polygon(c(OF.dat4$x,rev(OF.dat4$x)),c(OF.dat4$conf.low,rev(OF.dat4$conf.high)),col="#68228B33", lty=0, lwd=0.05)
polygon(c(R.dat4$x,rev(R.dat4$x)),c(R.dat4$conf.low,rev(R.dat4$conf.high)),col="#228B2233", lty=0, lwd=0.05)

legend(x=-1.5, y =2, legend= c("Native","Post-agricultural"), col = c("#228B2280","#68228B80"),box.lty=0, pch=19, cex =1.5)

######################
######################
### DATA FOR PERM ####
######################
######################

#read data
mirks1<-read.csv("MIRKSexp1SAS ranks_12_12_2019.csv", header=TRUE)
str(mirks1)
#make new pop variable:
mirks1$popsp<-paste(mirks1$treatment,mirks1$poptype,mirks1$poprep)
testdata<-mirks1
#set up loop:
Nsims = 1000 # number of permutations
for (i in 1:Nsims) {
  print('Beginning simulation') 
  data.permuted <- 
    group_by(testdata,species) %>% 
    mutate(popsp = sample(popsp)) %>% 
    ungroup() %>% as.data.frame() %>% 
    add_column(perm = i)-> perm.results 
  if (i==1) {all.perm.results <- perm.results} 
  else {all.perm.results <- rbind(all.perm.results,perm.results)} 
}
head(all.perm.results)
#separate pop to treatment,poptype and poprep to new.
all.perm.results.popsep<-separate(all.perm.results, popsp, sep = " ", into=c("NEWTreatment","NEWpoptype","NEWpoprep"))
head(all.perm.results.popsep)
#remove pre and res columns (21-38) and also poptype poprep:
all.perm.results.popsep$poptype<-NULL
all.perm.results.popsep$poprep<-NULL
all.perm.results.popsep$sitenum<-NULL
all.perm.results.popsep$treatment<-NULL
all.perm.results<-all.perm.results.popsep[  ,c(1:18,37:40)] 
write.table(all.perm.results, file= "CSDMycResp1000Perm_4.27.20.txt",quote=FALSE)

#######################
#######################
#### PERM DIST SIG ####
#######################
#######################

##ABOVEGROUND
distdat<- read.table("PERMEstimatesForR_5.4.20Above.txt", header=TRUE)

#AMF VS STERILE:
T.est<- 58.0380 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterile<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.000

#AMF PRAIRIE VS OLD FIELD:
T.est<- -2.3654 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFpoptype<T.est,]
nrow(filtered.distdat) #190
1-(nrow(filtered.distdat)/1000) #0.81

#AMF VS STERILE*POPTPYE:
T.est<- 2.1148 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterilePlantpoptype<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.418

#AMF PRARIRIE VS OLD FIELD*POPYPE:
#to get P value:
T.est<- 8.4094 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFpoptypePlantpoptype<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.082 

##BELOWGROUND
distdat<- read.table("PERMEstimatesForR_5.4.20Below.txt", header=TRUE)

#AMF VS STERILE:
T.est<- 52.5406 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterile<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.000

#AMF PRAIRIE VS OLD FIELD:
T.est<- -4.9216 #fill with real estimate.
filtered.distdat<-distdat[distdat$AMFpoptype>T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.056

#AMF VS STERILE*POPTPYE
T.est<- -2.9662 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterilePlantpoptype>T.est,] 
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.39

#AMF PRARIRIE VS OLD FIELD*POPYPE:
T.est<- 2.9518 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFpoptypePlantpoptype<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.319

#BELOWGROUND AMFV STERILE*POPTYPE*SPECIES:
#CALLED BELOW3WAY
distdat<- read.table("PERMEstimatesForR_5.29.20.txt", header=TRUE)
T.est<- 0.0048 #fill with real estimate
filtered.distdat<-distdat[distdat$BELOW3WAY>T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.

##ABOVEGROUND AMFV STERILE*POPTYPE*SPECIES:
#CALLED BELOW3WAY
distdat<- read.table("PERMEstimatesForR_5.29.20.txt", header=TRUE)
T.est<- 0.057 #fill with real estimate
filtered.distdat<-distdat[distdat$ABOVE3WAY>T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#ABOVEGROUND CONTRAST 
#ALL SPECIES AMF*STERILE

#BELOWGROUND CONTRAST 
#ALL SPECIES AMF*STERILE

distdat<- read.table("AMFSterile_EachSpeciesPERMEstimatesForR_5.29.20.txt", header=TRUE)
#ABOVE:

#EST:
#Dogbane: 19.2039
#Ironweed: 78.6154
#Milkweed: 58.7585
#Solidago: 76.2045

#MILKWEED:
hist(distdat$Milkweed_A)
#to get P value:
T.est<- 58.7585#fill with real estimate
filtered.distdat<-distdat[distdat$Milkweed_A<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#SOLIDAGO:
hist(distdat$Solidago_A)
#to get P value:
T.est<- 76.2045#fill with real estimate
filtered.distdat<-distdat[distdat$Solidago_A<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#DOGBANE:
hist(distdat$Dogbane_A)
#to get P value:
T.est<- 19.2039#fill with real estimate
filtered.distdat<-distdat[distdat$Dogbane_A<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.019

#IRONWEED:
hist(distdat$Ironweed_A)
#to get P value:
T.est<- 78.6154#fill with real estimate
filtered.distdat<-distdat[distdat$Ironweed_A<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0


#BELOW:

#EST:
#Dogbane: 14.1428
#Ironweed: 66.0503
#Milkweed: 59.4958
#Solidago: 71.0328

#MILKWEED:
hist(distdat$Milkweed_B)
#to get P value:
T.est<- 59.4958#fill with real estimate
filtered.distdat<-distdat[distdat$Milkweed_B<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#SOLIDAGO:
hist(distdat$Solidago_B)
#to get P value:
T.est<- 71.0328#fill with real estimate
filtered.distdat<-distdat[distdat$Solidago_B<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#DOGBANE:
hist(distdat$Dogbane_B)
#to get P value:
T.est<- 14.1428#fill with real estimate
filtered.distdat<-distdat[distdat$Dogbane_B<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.085

#IRONWEED:
hist(distdat$Ironweed_B)
#to get P value:
T.est<- 66.0503#fill with real estimate
filtered.distdat<-distdat[distdat$Ironweed_B<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0

#IRONWEED:DOGBANE: AMFsterilePlantpoptype
#DOGBANE:
distdat<- read.table("DBBelow_SpeciesPERMEstimatesForR_5.29.20.txt", header=TRUE)
hist(distdat$AMFsterilePlantpoptype)
#to get P value:
T.est<- 30.9832 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterilePlantpoptype<T.est,]
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.058

#IRONWEED:
distdat<- read.table("IWBelow_SpeciesPERMEstimatesForR_5.29.20.txt", header=TRUE)
hist(distdat$AMFsterilePlantpoptype)
#to get P value:
T.est<- -42.9448 #fill with real estimate
filtered.distdat<-distdat[distdat$AMFsterilePlantpoptype>T.est,] #flip, neg
nrow(filtered.distdat)
1-(nrow(filtered.distdat)/1000) #0.036

